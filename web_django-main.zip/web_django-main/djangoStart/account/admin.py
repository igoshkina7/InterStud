from django.contrib import admin
from .models import Liked_post, Liked_job
# Register your models here.


admin.site.register(Liked_post)
admin.site.register(Liked_job)

